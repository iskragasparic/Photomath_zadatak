%kreira se baza znamenki i znakova

format = '.png';

for i = 1:38
    redni_broj = num2str(i);
    str = strcat(redni_broj, format);
    [I,tenzor_b,tenzor_z] = slika(str);
    for j = 1:10
        A = tenzor_b(:,:,j);
        znamenka = num2str(j-1);
        znamenka = strcat(znamenka, '_');
        string1 = 'baza/';
        string2 = '.png';
        lokacija = strcat(string1, znamenka, redni_broj, string2);
        imwrite(tenzor_b(:,:,j),lokacija);
    end
    
    for j = 1:6
        A = tenzor_z(:,:,j);
        
        if j == 1
            znak = 'plus';
        end
        
        if j == 2
            znak = 'minus';
        end

        if j == 3
            znak = 'puta';
        end

        if j == 4
            znak = 'kroz';
        end

        if j == 5
            znak = 'lijeva';
        end
            
        if j == 6
            znak = 'desno';
        end
            
        znak = strcat(znak, '_');
        string1 = 'baza/';
        string2 = '.png';
        lokacija = strcat(string1, znak, redni_broj, string2);
        imwrite(tenzor_z(:,:,j),lokacija);
    end
end
            