function[I,tenzor_b,tenzor_z] = slika(pic)

% funkcija prima sliku koju treba pretvoriti u bazu
% vraca finalnu "pociscenu" sliku
% i tenzor koji sadrzi pojedine znakove

I = imread(pic);

I = squeeze(I(:,:,1));
I = double(I);

I = mat2gray(I);

I = find_black(I);

% SVE NECRNO postavi na BIJELO
[m,n] = size(I);

for i = 1:m
    for j = 1:n
        if I(i,j) > 0.2
            I(i,j) = 1;
        end
    end
end

% TRAZENJE INDEKSA SLOVA/BROJEVA
indeksi = [];
indeksi2 = [];
flag = 0;
slovo_chk = floor(0.5*m);
flag_slovo = 0;

for j = 1:n
    if min(I(:,j)) < 0.2
        
        if flag == 0
            indeksi = [indeksi,j];
            flag = 1; %TRENUTNO SMO NA SLOVU
        end
        
%         if I(slovo_chk,j) < 0.2
%             flag_slovo = 1;
%         end
    end
    if min(I(:,j)) > 0.2 && flag == 1
        
        indeksi2 = [indeksi2, j-1];
        flag = 0;
        
%         flag = 0;
%         if flag_slovo == 0
%             [~,pom] = size(indeksi);
%             indeksi = indeksi(:,1:pom-1);
%         end
%         if flag_slovo == 1
%             indeksi2 = [indeksi2, j-1];
%         end
%         flag_slovo = 0;
    end
end

indeksi2 = [indeksi2, n];

max_sirina = max(indeksi2 - indeksi);
[in1,in2] = size(indeksi);

tenzor_b = []; %tenzor broj
tenzor_z = []; %tenzor znak

for i = 1:in2
    znak = I(:, indeksi(1,i):indeksi2(1,i));
    [z1,z2] = size(znak);
    
    novi = ones(z1+20, max_sirina + 40);
    razmak = 20 + floor((max_sirina - z2)/2);
   
    novi(11:z1+10, razmak+1:z2 + razmak) = znak;
    
    %SKALIRANJE

    novi = uint8(255 * novi);
    if i >= 1 && i <= 10
        novi = imresize(novi,[28 28]);
        novi = double(novi);
        novi = mat2gray(novi);
        
        [~,~,t3] = size(tenzor_b);
        tenzor_b(:,:, t3+1) = novi;
    else
        novi = imresize(novi,[16 16]);
        novi = double(novi);
        novi = mat2gray(novi);
        
        [~,~,t3] = size(tenzor_z);
        tenzor_z(:,:, t3+1) = novi;
    end
end

%prvi kreira na sve 0 zbog sintakse
if max(tenzor_b(:,:,1)) == 0
    tenzor_b(:,:,1) = [];
end
if max(tenzor_z(:,:,1)) == 0
    tenzor_z(:,:,1) = [];
end
