function[I] = find_black(R)

%funkcija nalazi prvu gotovo crnu stvar na slici, tj uklanja bijeli "okvir" oko znakova

[m,n] = size(R);

for i = 1:m
    pr = min(R(i,:));
    if pr < 0.1
        gornji = i;
        break
    end
end

for i = m:-1:1
    pr = min(R(i,:));
    if pr < 0.1
        donji = i;
        break
    end
end

I = R(gornji:donji, :);
[m,n] = size(I);

%LIJEVA STRANA:
for j = 1:n
    if min(I(:,j)) < 0.2
        prvi_crni_st = j;
        break;
    end
end

% for j=prvi_crni_st:n
%     count = 0;
%     for i = 1:m
%         if I(i,j) > 0.8
%             count = count+1;
%         end
%     end
%     if (count/m) > 2/3
%         lijevi = j;
%         break;
%     end
% end

I = I(:, prvi_crni_st:n);
[m,n] = size(I);

%DESNA STRANA:

for j = n:-1:1
    if min(I(:,j)) < 0.2
        zadnji_crni_st = j;
        break;
    end
end

I = I(:,1:zadnji_crni_st);
[m,n] = size(I);
